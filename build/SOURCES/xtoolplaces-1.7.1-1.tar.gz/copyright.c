char copyright[] =
"\
Copyright (c) 1993-1998 Xerox Corporation.  All Rights Reserved.\n\
    \n\
Permission to use, copy, modify  and  distribute  without  charge\n\
this  software,  documentation, images, etc. is granted, provided\n\
that this copyright and the author's name is retained.\n\
    \n\
A fee may be charged for this program ONLY to recover  costs  for\n\
distribution  (i.e.  media costs).  No profit can be made on this\n\
program.\n\
    \n\
The author assumes no responsibility for  disasters  (natural  or\n\
otherwise) as a consequence of use of this software.\n\
    \n\
Adam Stein (adam@iset.scan.mc.xerox.com)\n\
    \n\
";
